// popup.js — v1.3: fill, submit, confirm OK page, advance to next week.

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(['breakStart', 'breakEnd'], (r) => {
    if (r.breakStart) document.getElementById('breakStart').value = r.breakStart;
    if (r.breakEnd)   document.getElementById('breakEnd').value   = r.breakEnd;
  });
  document.getElementById('fillBtn')  .addEventListener('click', () => run('fill'));
  document.getElementById('submitBtn').addEventListener('click', () => run('fill_submit'));
  document.getElementById('allBtn')   .addEventListener('click', () => run('fill_submit_next'));
});

async function run(mode) {
  const breakStart = document.getElementById('breakStart').value.trim();
  const breakEnd   = document.getElementById('breakEnd').value.trim();
  chrome.storage.local.set({ breakStart, breakEnd });

  setButtonsDisabled(true);
  setStatus({ fill: 'Filling…', fill_submit: 'Filling & submitting…', fill_submit_next: 'Working…' }[mode], 'info');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || !tab.url.includes('compass.talent.cognizant.com')) {
      setStatus('Open your Compass timesheet tab first, then click the extension.', 'error');
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: pageFn,
      args: [breakStart, breakEnd, mode]
    });

    const agg = { filled:0, skipped:0, submitted:false, confirmed:false,
                  advanced:false, hours:null, hoursMatched:null,
                  errors:[], steps:[], diagnostics:[] };
    for (const r of results) {
      if (!r || !r.result) continue;
      const x = r.result;
      agg.filled  += x.filled  || 0;
      agg.skipped += x.skipped || 0;
      if (x.submitted) agg.submitted = true;
      if (x.confirmed) agg.confirmed = true;
      if (x.advanced)  agg.advanced  = true;
      if (x.hours)     agg.hours     = x.hours;
      if (x.hoursMatched !== undefined && x.hoursMatched !== null) agg.hoursMatched = x.hoursMatched;
      if (x.errors)      agg.errors      = agg.errors.concat(x.errors);
      if (x.steps)       agg.steps       = agg.steps.concat(x.steps);
      if (x.diagnostics) agg.diagnostics = agg.diagnostics.concat(x.diagnostics);
    }

    renderResult(mode, agg);
  } catch (e) {
    setStatus('Error: ' + e.message, 'error');
  } finally {
    setButtonsDisabled(false);
  }
}

function renderResult(mode, agg) {
  if (agg.filled === 0 && agg.skipped === 0 && !agg.submitted && !agg.advanced) {
    let msg = 'No timesheet rows detected.';
    if (agg.errors.length) msg += '\n• ' + agg.errors.join('\n• ');
    setStatus(msg, 'error');
    return;
  }

  const lines = [];

  if (agg.filled > 0)  lines.push(`✓ Filled ${agg.filled} row${agg.filled === 1 ? '' : 's'}`);
  if (agg.skipped > 0) lines.push(`• Left ${agg.skipped} row${agg.skipped === 1 ? '' : 's'} untouched`);

  if (mode !== 'fill') {
    if (agg.submitted) lines.push('✓ Submit clicked');
    else               lines.push('✗ Submit did not run');
    if (agg.confirmed) lines.push('✓ Confirmation OK clicked');
  }

  if (mode === 'fill_submit_next') {
    if (agg.hours) {
      const s = agg.hours.scheduled, a = agg.hours.actual;
      const sStr = s === null ? '?' : s.toFixed(2);
      const aStr = a === null ? '?' : a.toFixed(2);
      lines.push(`• Hours: actual ${aStr} / scheduled ${sStr}`);
    }
    if (agg.advanced)              lines.push('✓ Moved to next week →');
    else if (agg.hoursMatched === false) lines.push('• Hours don\'t match — staying on this week');
    else if (agg.hoursMatched === null && agg.submitted) lines.push('• Hours not yet readable');
  }

  if (agg.errors.length) {
    lines.push('—');
    agg.errors.forEach(e => lines.push('! ' + e));
  }

  if (agg.filled === 0 && agg.diagnostics.length && mode === 'fill') {
    const d = agg.diagnostics[0];
    lines.push('—');
    lines.push(`Sample row: In="${d.in}" Brk="${d.brk}" In₂="${d.lunchIn}" Out="${d.out}"`);
  }

  const kind = agg.errors.length > 0 ? 'info' : 'success';
  setStatus(lines.join('\n'), kind);
}

function setStatus(text, kind) {
  const el = document.getElementById('status');
  el.textContent = text;
  el.className = 'status show ' + (kind || '');
}

function setButtonsDisabled(disabled) {
  ['fillBtn','submitBtn','allBtn'].forEach(id => {
    document.getElementById(id).disabled = disabled;
  });
}

// ══════════════════════════════════════════════════════════════
// Page-side function (async). Runs in every frame; the one with
// the timesheet does the real work.
// ══════════════════════════════════════════════════════════════
async function pageFn(rawStart, rawEnd, mode) {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function normalizeTime(t) {
    t = String(t || '').trim().toUpperCase().replace(/\s+/g, '');
    if (!t) return '';
    if (/^\d{1,2}$/.test(t)) {
      const h = parseInt(t, 10);
      if (h === 0)  return '12:00:00AM';
      if (h < 12)   return `${h}:00:00AM`;
      if (h === 12) return '12:00:00PM';
      if (h <= 23)  return `${h-12}:00:00PM`;
      return t;
    }
    const m = t.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?(AM|PM)?$/);
    if (!m) return t;
    let hh = parseInt(m[1], 10);
    const mm = m[2], ss = m[3] || '00';
    let ampm = m[4];
    if (!ampm) {
      if (hh === 0)       { hh = 12; ampm = 'AM'; }
      else if (hh < 12)   { ampm = 'AM'; }
      else if (hh === 12) { ampm = 'PM'; }
      else                { hh -= 12; ampm = 'PM'; }
    } else if (ampm === 'PM' && hh > 12) {
      hh -= 12;
    }
    return `${hh}:${mm}:${ss}${ampm}`;
  }

  function nativeSet(input, value) {
    const proto = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
    if (proto && proto.set) proto.set.call(input, value);
    else input.value = value;
    input.dispatchEvent(new Event('input',  { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function bodyText() {
    return document.body ? (document.body.innerText || document.body.textContent || '') : '';
  }

  function clickableEls() {
    return Array.from(document.querySelectorAll(
      'input[type="button"], input[type="submit"], button, a, [role="button"]'
    ));
  }

  function findByText(re) {
    return clickableEls().find(el => {
      if (el.disabled) return false;
      if (el.offsetParent === null && el.tagName !== 'A') return false; // links can be visible without offsetParent
      const txt = (el.value || el.textContent || el.title || el.getAttribute('aria-label') || '').trim();
      return re.test(txt);
    });
  }

  function findById(includeRe, excludeRe) {
    return clickableEls().find(el => {
      const id = (el.id || el.name || '').toUpperCase();
      if (!includeRe.test(id)) return false;
      if (excludeRe && excludeRe.test(id)) return false;
      return !el.disabled;
    });
  }

  function readHours() {
    const text = bodyText();
    const sched  = text.match(/Scheduled\s+Hours:\s*([\d.,]+)/i);
    const actual = text.match(/Actual\s+working\s+Hours:\s*([\d.,]+)/i);
    const parse = (m) => m ? parseFloat(m[1].replace(',', '.')) : null;
    return { scheduled: parse(sched), actual: parse(actual) };
  }

  async function waitFor(predicateFn, maxMs = 12000, step = 200) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
      try { if (predicateFn()) return true; } catch(e) {}
      await sleep(step);
    }
    return false;
  }

  async function waitForNoLoading(maxMs = 8000) {
    return waitFor(() => {
      const loading = document.querySelector(
        '.processBackdropMask, #processing, .ps-loader, ' +
        '[id*="WAIT"][style*="block"], [class*="loading"][style*="block"]'
      );
      return !loading || loading.offsetParent === null;
    }, maxMs, 250);
  }

  async function dismissPopups(maxAttempts = 4) {
    let dismissed = 0;
    for (let i = 0; i < maxAttempts; i++) {
      const btn = findByText(/^(yes|continue|confirm)$/i);
      if (btn) { btn.click(); dismissed++; await sleep(500); }
      else break;
    }
    return dismissed;
  }

  // Pre-arm native dialog overrides
  try {
    window.confirm = function() { return true; };
    window.alert   = function() { return undefined; };
  } catch (e) {}

  const TIME_RE = /^\s*\d{1,2}:\d{2}(:\d{2})?\s*(AM|PM)\s*$/i;
  const normStart = normalizeTime(rawStart);
  const normEnd   = normalizeTime(rawEnd);

  let filled = 0, skipped = 0;
  let submitted = false, confirmed = false, advanced = false;
  let hours = null, hoursMatched = null;
  const errors = [];
  const steps = [];
  const diagnostics = [];

  // ── STEP 1: Fill rows ──────────────────────────────────
  const trs = document.querySelectorAll('tr');
  trs.forEach((tr) => {
    const allInputs = Array.from(tr.querySelectorAll('input[type="text"]'))
      .filter(i => !i.disabled && !i.readOnly && i.closest('tr') === tr);
    if (allInputs.length < 4) return;

    const timeIdxs = [];
    allInputs.forEach((inp, idx) => {
      if (TIME_RE.test(inp.value || '')) timeIdxs.push(idx);
    });
    if (timeIdxs.length < 2) return;

    const firstIdx = timeIdxs[0], lastIdx = timeIdxs[timeIdxs.length - 1];
    if (lastIdx - firstIdx !== 3) return;

    const breakField   = allInputs[firstIdx + 1];
    const lunchInField = allInputs[firstIdx + 2];
    const outField     = allInputs[firstIdx + 3];
    const inField      = allInputs[firstIdx];

    diagnostics.push({
      in: inField.value, brk: breakField.value,
      lunchIn: lunchInField.value, out: outField.value
    });

    if (TIME_RE.test(breakField.value) || TIME_RE.test(lunchInField.value)) {
      skipped++; return;
    }

    try { breakField.focus(); } catch(e) {}
    nativeSet(breakField, normStart);
    breakField.dispatchEvent(new Event('blur', { bubbles: true }));

    try { lunchInField.focus(); } catch(e) {}
    nativeSet(lunchInField, normEnd);
    lunchInField.dispatchEvent(new Event('blur', { bubbles: true }));

    filled++;
  });

  // Only the frame that found rows continues with submit/confirm/next.
  if (filled + skipped === 0) {
    return { filled, skipped, errors, steps, diagnostics: [] };
  }
  steps.push(`fill: +${filled} / skip ${skipped}`);

  if (mode === 'fill') {
    return { filled, skipped, errors, steps, diagnostics };
  }

  // ── STEP 2: Submit ─────────────────────────────────────
  await sleep(1000);
  await waitForNoLoading();

  const submitEl = findByText(/^submit$/i) || findById(/SUBMIT/i, /CANCEL/i);
  if (!submitEl) {
    errors.push('Submit button not found');
    return { filled, skipped, errors, steps, diagnostics };
  }
  submitEl.click();
  submitted = true;
  steps.push('submit clicked');

  // ── STEP 3: Submit Confirmation page → click OK ────────
  // Wait for either the confirmation text to appear, or an OK button.
  const confirmAppeared = await waitFor(() => {
    const text = bodyText();
    if (/submit\s+confirmation/i.test(text)) return true;
    if (/was\s+successful/i.test(text))      return true;
    if (/is\s+submitted/i.test(text))        return true;
    return false;
  }, 12000);

  if (confirmAppeared) {
    steps.push('confirmation page detected');
    await sleep(400);
    // The OK on Submit Confirmation page is the only OK present at this point.
    const okBtn = findByText(/^ok$/i) || findById(/(^|_)OK(_|$|\$)/i);
    if (okBtn) {
      okBtn.click();
      confirmed = true;
      steps.push('OK clicked');
      // Wait for return to the timesheet grid
      await waitFor(() => {
        const text = bodyText();
        return /reported\s+hours/i.test(text) && /scheduled\s+hours/i.test(text);
      }, 12000);
      await sleep(500);
    } else {
      errors.push('Submit Confirmation OK button not found');
    }
  } else {
    // No confirmation page appeared — maybe an inline popup; try dismissing.
    await dismissPopups();
    await waitForNoLoading();
  }

  if (mode === 'fill_submit') {
    return { filled, skipped, submitted, confirmed, errors, steps, diagnostics };
  }

  // ── STEP 4: Hours check ────────────────────────────────
  await sleep(300);
  hours = readHours();
  if (hours.scheduled === null || hours.actual === null) {
    errors.push('Could not read Scheduled / Actual hours');
    return { filled, skipped, submitted, confirmed, hours, hoursMatched, errors, steps, diagnostics };
  }
  hoursMatched = Math.abs(hours.scheduled - hours.actual) < 0.01;
  steps.push(`hours ${hours.actual}/${hours.scheduled} ${hoursMatched ? 'match' : 'mismatch'}`);
  if (!hoursMatched) {
    return { filled, skipped, submitted, confirmed, hours, hoursMatched, advanced: false, errors, steps, diagnostics };
  }

  // ── STEP 5: Next Week ──────────────────────────────────
  await sleep(300);
  const nextEl = findByText(/^next\s*week$/i) || findById(/NEXT.*(WEEK|WK)/i);
  if (!nextEl) {
    errors.push('"Next Week" link not found');
    return { filled, skipped, submitted, confirmed, hours, hoursMatched, errors, steps, diagnostics };
  }
  nextEl.click();
  advanced = true;
  steps.push('Next Week clicked');

  // Wait for next week's timesheet to load
  await waitFor(() => {
    const text = bodyText();
    return /reported\s+hours/i.test(text);
  }, 10000);
  await dismissPopups();
  await waitForNoLoading();

  return { filled, skipped, submitted, confirmed, hours, hoursMatched, advanced, errors, steps, diagnostics };
}
