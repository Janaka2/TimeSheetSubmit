# Cognizant Timesheet Autofill

A Chrome extension that fills the **Break** and lunch-back **In** columns on your Cognizant Compass timesheet, submits it, clicks past the Submit Confirmation page, and advances to next week if your hours add up — all in one click.

## Buttons

| Button | Does |
|---|---|
| **Fill, Submit & Next →** | Fill empty rows → click Submit → click OK on the "Submit Confirmation" page → if Scheduled Hours = Actual working Hours, click Next Week. |
| **Fill & Submit** | Fill empty rows → click Submit → click OK on the Submit Confirmation page. Stops there. |
| **Fill only** | Just fills. You drive the rest. |

For every row in the weekly grid where **In (1st column)** and **Out (4th column)** are already filled in, it sets:
- **Break** → break-start time (default `12` → `12:00:00PM`)
- **In (middle)** → break-end time (default `13` → `1:00:00PM`)

Rows where In or Out are empty (holidays, weekends, days off) are **left alone**. Rows where Break is already filled are also left alone.

## Install (one time)
1. Open Chrome → `chrome://extensions`
2. Turn on **Developer mode** (top-right)
3. Click **Load unpacked** → pick the unzipped `timesheet-autofill` folder
4. Pin it to the toolbar via the puzzle-piece icon

## Updating
After replacing the folder with a new version: open `chrome://extensions`, find "Cognizant Timesheet Autofill", and click the **reload (↻)** icon on its card. Chrome doesn't auto-pick-up file changes.

## Time format
`12` / `13` and `12:00:00PM` / `1:00:00PM` both work. Short numbers auto-convert to PeopleSoft's `H:MM:SSAM/PM` format.

## What's handled automatically
- The **Submit Confirmation** page (the one with "The Submit was successful." and an OK button) — the OK button is clicked once the page appears, and the extension waits for the timesheet to come back before doing anything else.
- Any popup with **OK / Yes / Continue / Confirm** buttons during the flow.
- Native browser dialogs (`window.confirm` / `window.alert`) are pre-overridden to auto-accept, in case PeopleSoft fires them.
- European decimal format for hours (`42,00`) is parsed correctly.

## Safety
- Only touches rows where In and Out already hold a time value
- Won't overwrite a Break/middle-In that already contains a valid time
- **Next Week** only fires when `|Scheduled − Actual| < 0.01` — holiday weeks with mismatched totals stay put for manual review
- Restricted to `compass.talent.cognizant.com` via host permission
- No data leaves your browser — no analytics, no network calls
